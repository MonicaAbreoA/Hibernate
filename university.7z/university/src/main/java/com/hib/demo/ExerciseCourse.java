package com.hib.demo;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
  
import com.hib.entities.Course;
import com.hib.entities.Professor;
import com.hib.init.HibernateUtil;  

public class ExerciseCourse {
	public static void main(String[] args) {  
		  
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();  
        Session session = sessionFactory.openSession();  
        session.beginTransaction(); 
        
        Query query =  session.createQuery("select p from Professor p"); 
        List<Professor> professors = query.list();
        
        Course course;
        
        for(int index = 1; index < 4; index++){
        	course = new Course();
        	course.setNameCourse("course" + index);
            course.setProfessor(professors.get(0));
            session.save(course);
        }
        
        for(int index = 4; index < 8; index++){
        	course = new Course();
        	course.setNameCourse("course" + index);
            course.setProfessor(professors.get(3));
            session.save(course);
        }
        
        course = new Course();
    	course.setNameCourse("course8");
        course.setProfessor(professors.get(4));
        session.save(course);
        
        session.getTransaction().commit();  
        session.close();  
    }  
}
