package com.hib.demo;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.hib.entities.Course;

import com.hib.init.HibernateUtil;

public class ExerciseQuantity {

	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		Query query = session.createQuery("select c from Course c ");
		List<Course> courses = query.list();

		System.out.println("Cursos con mas de 3 estudiantes");
		System.out.println("Id Course   Name   Id Professor");
		for (Course current : courses) {
			if (current.getStudents().size() >= 3) {
				System.out.println(current.getIdCourse() + "   " + current.getNameCourse() + "   "
						+ current.getProfessor().getIdProfessor());
			}
		}
		session.getTransaction().commit();
		session.close();
	}

}
