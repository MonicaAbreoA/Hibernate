package com.hib.demo;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hib.entities.Course;
import com.hib.entities.Student;
import com.hib.init.HibernateUtil;

public class ExerciseStudentToCourse {

	public static void main(String[] args) {

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		int indexStudent;

		Query query = session.createQuery("select s from Student s");
		List<Student> students = query.list();

		query = session.createQuery("select c from Course c");
		List<Course> courses = query.list();

		courses.get(0).setStudents(students.subList(0, 5));
		courses.get(2).setStudents(students.subList(4, 9));
		courses.get(4).setStudents(students.subList(0, 5));
		courses.get(6).setStudents(students.subList(4, 9));
		courses.get(7).setStudents(students.subList(0, 5));

		for (int indexCourse = 0; indexCourse < 8; indexCourse++) {
			session.update(courses.get(indexCourse));
		}

		for (indexStudent = 0; indexStudent < 5; indexStudent++) {
			students.get(indexStudent).getCourses().add(courses.get(0));
			students.get(indexStudent).getCourses().add(courses.get(4));
			students.get(indexStudent).getCourses().add(courses.get(7));
			session.update(students.get(indexStudent));
		}

		for (indexStudent = 4; indexStudent < 9; indexStudent++) {
			students.get(indexStudent).getCourses().add(courses.get(2));
			students.get(indexStudent).getCourses().add(courses.get(6));
			session.update(students.get(indexStudent));
		}

		session.getTransaction().commit();

		session.close();

	}

}
