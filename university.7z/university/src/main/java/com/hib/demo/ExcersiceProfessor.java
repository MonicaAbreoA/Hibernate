package com.hib.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hib.entities.Professor;
import com.hib.init.HibernateUtil;

public class ExcersiceProfessor {

	public static void main(String[] args) {

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		Professor professor;

		for (int index = 1; index < 6; index++) {
			professor = new Professor();
			professor.setFirstName("professor" + index);
			session.save(professor);
		}
		session.getTransaction().commit();
		session.close();
	}
}
