package com.hib.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "student", catalog = "university")
public class Student {

	@Id
	@GeneratedValue
	@Column(name = "id_student")
	private Integer idStudent;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "age")
	private Integer age;

	@ManyToMany(targetEntity = Course.class, cascade = CascadeType.ALL)
	@JoinTable(name = "courses_per_student", catalog = "university", joinColumns = {
			@JoinColumn(name = "id_student") }, inverseJoinColumns = { @JoinColumn(name = "id_course") })
	private List<Course> courses = new ArrayList<Course>();

	public Student() {
	};

	public Student(Integer id, String firstName, Integer age) {
		this.idStudent = id; 
		this.firstName = firstName;
		this.age = age;
	}

	public Integer getIdStudent() {
		return idStudent;
	}

	public void setIdStudent(Integer idStudent) {
		this.idStudent = idStudent;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

}
