package com.hib.entities;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "professor", catalog = "university")
public class Professor {

	@Id
	@GeneratedValue
	@Column(name = "id_professor")
	private Integer idProfessor;

	@Column(name = "first_name")
	private String firstName;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "professor")
	private List<Course> courses = new ArrayList<Course>();

	public Professor() {
	}

	public Professor(Integer id, String firstName) {
		this.idProfessor = id;
		this.firstName = firstName;
	}

	public Integer getIdProfessor() {
		return idProfessor;
	}

	public void setIdProfessor(Integer idProfessor) {
		this.idProfessor = idProfessor;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

}
