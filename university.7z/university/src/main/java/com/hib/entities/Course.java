package com.hib.entities;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "course", catalog = "university")
public class Course {

	@Id
	@GeneratedValue
	@Column(name = "id_course")
	private Integer idCourse;

	@Column(name = "name_course")
	private String nameCourse;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_professor", nullable = false)
	private Professor professor;

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "courses")
	private List<Student> students = new ArrayList<Student>();

	public Course() {
	}

	public Course(Integer id, String nameCourse) {
		super();
		this.idCourse = id;
		this.nameCourse = nameCourse;
	}

	public Integer getIdCourse() {
		return idCourse;
	}

	public void setIdCourse(Integer idCourse) {
		this.idCourse = idCourse;
	}

	public String getNameCourse() {
		return nameCourse;
	}

	public void setNameCourse(String nameCourse) {
		this.nameCourse = nameCourse;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

}
